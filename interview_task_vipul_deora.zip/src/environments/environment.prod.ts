export const environment = {
  production: true,
  BASE_URL: 'https://reqres.in'
};
