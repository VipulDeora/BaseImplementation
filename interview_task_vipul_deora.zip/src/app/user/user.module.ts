import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserBaseComponent } from './smart-components/user-base/user-base.component';
import { UserListComponent } from './smart-components/user-list/user-list.component';
import {SharedModule} from '../shared/shared.module';
import { UserDetailsComponent } from './smart-components/user-details/user-details.component';

@NgModule({
  declarations: [UserBaseComponent, UserListComponent, UserDetailsComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    SharedModule
  ],
  entryComponents: [UserDetailsComponent]
})
export class UserModule { }
