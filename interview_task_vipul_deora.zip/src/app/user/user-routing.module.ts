import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UserBaseComponent} from './smart-components/user-base/user-base.component';

const routes: Routes = [
  {
    path: '',
    component: UserBaseComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
