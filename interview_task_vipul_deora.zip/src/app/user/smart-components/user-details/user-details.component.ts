import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {UserService} from '../services/user.service';

export class UserDetails {
  id: number;
  name: string;
  job: string;
  editState: boolean;
}

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  name = '';
  isLoading = false;
  job = '';
  userId: number;

  constructor(public userService: UserService,
              public dialogRef: MatDialogRef<UserDetailsComponent>,
              @Inject(MAT_DIALOG_DATA) public data: UserDetails) {
  }

  ngOnInit() {
    this.userId = this.data.id;
    if (this.data.editState) {
      this.name = this.data.name;
      this.job = this.data.job;
    }
  }

  onClose(data?: any) {
    this.dialogRef.close(data || null);
  }

  executeRequest() {
    if (this.data.editState) {
      this.editUser();
    } else {
      this.addNewUser();
    }
  }

  isNullOrEmpty(value: string) {
    return !value || !value.trim();
  }

  private editUser() {
    this.isLoading = true;
    this.userService.updateUser(this.userId, {
        name: this.name,
        job: this.job
      },
      () => {
        this.isLoading = false;
        this.onClose('success');
      },
      () => {
        this.isLoading = false;
        this.onClose('failure');
      }
    );
  }

  private addNewUser() {
    this.isLoading = true;
    this.userService.createUser({
        name: this.name,
        job: this.job
      },
      () => {
        this.isLoading = false;
        this.onClose('success');
      },
      () => {
        this.isLoading = false;
        this.onClose('failure');
      }
    );
  }
}
