import { Injectable } from '@angular/core';
import {HttpService} from '../../../shared/services/http.service';

import {environment} from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpService: HttpService) { }

  getUserList(successCallBack, failureCallBack) {
    const URL = environment.BASE_URL + '/api/users';
    this.httpService.executeGetRequest(URL, successCallBack, failureCallBack);
  }

  deleteUser(userId: number, successCallBack, failureCallback) {
    const URL = environment.BASE_URL + '/api/users/' + userId;
    this.httpService.delete(URL, successCallBack, failureCallback);
  }

  updateUser(userId: number, userData, successCallBack, failureCallback) {
    const URL = environment.BASE_URL + '/api/users/' + userId;
    this.httpService.executePutRequest(URL, userData, successCallBack, failureCallback);
  }

  createUser(userData, successCallBack, failureCallback) {
    const URL = environment.BASE_URL + '/api/users/';
    this.httpService.executePostRequest(URL, userData, successCallBack, failureCallback);
  }
}
