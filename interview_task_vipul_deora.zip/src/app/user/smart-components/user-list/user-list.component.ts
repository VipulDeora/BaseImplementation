import {Component, OnInit} from '@angular/core';
import {UserService} from '../services/user.service';
import {MatDialog} from '@angular/material';
import {UserDetails, UserDetailsComponent} from '../user-details/user-details.component';
import {isNullOrUndefined} from 'util';

export class User {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  avatar: string;
}

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  dataSource: User[];
  isLoading = false;
  COLUMN_DATA = [
    {key: 'id', header: 'Id'},
    {key: 'email', header: 'User name'},
    {key: 'first_name', header: 'First name'},
    {key: 'last_name', header: 'Last name'},
  ];


  constructor(private userService: UserService,
              public dialog: MatDialog) {
  }

  ngOnInit() {
    this.userService.getUserList(
      (response) => {
        for (let i = 0; i < 4; i++) {
          response.data = [...response.data, ...response.data];
        }
        this.dataSource = response.data;
      },
      (error) => {
        alert(error);
      });
  }

  performAction(actionObject: { action: string; userObject: User }) {
    switch (actionObject.action) {
      case 'edit':
        this.editUser(actionObject.userObject);
        break;
      case 'delete':
        this.deleteUser(actionObject.userObject);
    }
  }

  private editUser(userObject: User) {
    const sendUserDetails = new UserDetails();
    sendUserDetails.id = userObject.id;
    sendUserDetails.job = 'leader';
    sendUserDetails.name = userObject.first_name;
    sendUserDetails.editState = true;
    const dialogRef = this.dialog.open(UserDetailsComponent, {
      data: sendUserDetails
    });
    dialogRef.afterClosed()
      .subscribe(result => {
        if (!isNullOrUndefined(result)) {
          // cannot update the table as the data is different
          // for update API
          alert(result);
        }
      });
  }

  private deleteUser(userObject: User) {
    this.isLoading = true;
    this.userService.deleteUser(userObject.id,
      () => {
        this.isLoading = false;
        alert('User with id ${userObject.id} deleted successfully!!');
        this.dataSource = this.dataSource.filter(user => user.id !== userObject.id);
      },
      () => {
        this.isLoading = false;
        alert('User could not be deleted');
      });
  }
}
