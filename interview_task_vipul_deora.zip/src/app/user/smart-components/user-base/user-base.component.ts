import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import {UserDetails, UserDetailsComponent} from '../user-details/user-details.component';
import {isNullOrUndefined} from 'util';

@Component({
  selector: 'app-user-base',
  templateUrl: './user-base.component.html',
  styleUrls: ['./user-base.component.css']
})
export class UserBaseComponent implements OnInit {

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  addUser() {
    const newUser = new UserDetails();
    newUser.editState = false;
    const dialogRef = this.dialog.open(UserDetailsComponent, {
      data: newUser
    });
    dialogRef.afterClosed()
      .subscribe(result => {
        if (!isNullOrUndefined(result)) {
          // cannot update the table as the data is different
          // for update API
          alert(result);
        }
      });
  }
}
