import { Injectable } from '@angular/core';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';

import * as APP_CONST from '../constants/application-constants';
import {catchError} from 'rxjs/operators';
import {AuthorizationService} from '../services/authorization.service';
@Injectable({
  providedIn: 'root'
})
export class InterceptService implements HttpInterceptor{

  constructor(private authService: AuthorizationService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (localStorage.getItem(APP_CONST.AUTHORIZATION) && localStorage.getItem('loggedUser')) {
      return next.handle(this.addTokenToRequest(req, localStorage.getItem(APP_CONST.AUTHORIZATION)))
        .pipe(
          catchError(err => {
            if (err instanceof HttpErrorResponse) {
              if (err.status === 401) {
                this.authService.logout();
              } else {
                return throwError(err);
              }
            } else {
              return throwError(err);
            }
          }));
    } else {
      console.log('Authorization or Logged User Info not saved');
      this.authService.logout();
    }
  }

  /**
   * Method to modify request header
   * */
  private addTokenToRequest(request: HttpRequest<any>, token: string): HttpRequest<any> {
    return request.clone({
      setHeaders: {
        Authorization: token,
      }
    });
  }
}
