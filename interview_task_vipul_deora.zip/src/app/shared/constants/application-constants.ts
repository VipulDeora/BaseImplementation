export const AUTHORIZATION = 'Authorization';
