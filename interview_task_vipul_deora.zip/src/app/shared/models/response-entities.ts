export class ErrorEntity {
  headers: Headers;
  status: number;
  statusText: string;
  url: string;
  ok: boolean;
  name: string;
  message: string;
  error: Error;
}

export class Error {
  error: string;
}

export class Headers {
  normalizedNames: NormalizedNames;
  lazyUpdate?: any;
}

export class NormalizedNames {
}
