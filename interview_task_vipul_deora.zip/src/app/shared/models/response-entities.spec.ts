import { ResponseEntities } from './response-entities';

describe('ResponseEntities', () => {
  it('should create an instance', () => {
    expect(new ResponseEntities()).toBeTruthy();
  });
});
