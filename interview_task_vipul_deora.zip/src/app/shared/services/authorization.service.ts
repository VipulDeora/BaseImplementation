import { Injectable } from '@angular/core';
import {Router} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {

  constructor(private router: Router) { }

  logout() {
    localStorage.clear();
    return this.navigateToLogin();
  }

  /**
   * Navigate to Login and return false
   */
  private navigateToLogin() {
    this.router.navigate(['/login']).then();
    return false;
  }
}
