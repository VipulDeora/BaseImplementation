import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {ErrorEntity} from '../models/response-entities';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private httpClient: HttpClient) { }

  executeGetRequest(uri: string, successCallback: any, failureCallback: any) {
    return this.httpClient.get(uri).subscribe((response) => {
      successCallback(response);

    }, (error: ErrorEntity) => {
      failureCallback(error.error.error);
    });
  }

  executeGetRequestParams(uri: string, params: HttpParams, successCallback: any, failureCallback: any) {
    return this.httpClient.get(uri, {params}).subscribe((response) => {
      successCallback(response);

    }, (error: ErrorEntity) => {
      failureCallback(error.error.error);
    });

  }

  executePostRequest(uri: string, data: any, successCallback: any, failureCallback: any) {
    return this.httpClient.post(uri, data).subscribe((response) => {
      successCallback(response);
    }, (error: ErrorEntity) => {
      failureCallback(error.error.error);
    });
  }

  delete(uri: string, successCallback: any, failureCallback: any) {
    return this.httpClient.delete(uri).subscribe((responseEntity) => {
      successCallback(responseEntity);
    }, (errorEntity: ErrorEntity) => {
      failureCallback(errorEntity);
    });
  }

  executePutRequest(uri: string, data: any, successCallback, failureCallback) {
    return this.httpClient.put(uri, data).subscribe((responseEntity) => {
      successCallback(responseEntity);
    }, (errorEntity) => {
      failureCallback(errorEntity);
    });
  }
}
