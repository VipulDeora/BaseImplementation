import {Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild} from '@angular/core';
import {isNullOrUndefined} from 'util';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';
import {User} from '../../../../user/smart-components/user-list/user-list.component';

export class ColumnData {
  key: string;
  header: string;
}
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit, OnChanges {

  @Input() data: any[];
  @Input() columnData: ColumnData[];
  @Output() action = new EventEmitter<{userObject: User, action: string}>();
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[];
  isLoading = true;

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges() {
    if (!isNullOrUndefined(this.data) && !isNullOrUndefined(this.columnData)) {
      this.isLoading = false;
      this.extractColumnKeys();
      this.dataSource = new MatTableDataSource(this.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  private extractColumnKeys() {
    this.displayedColumns = [];
    for (const column of this.columnData) {
      this.displayedColumns.push(column.key);
    }
    this.displayedColumns.push('actions');
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteUser($event: User) {
    this.action.emit({
      action: 'delete',
      userObject: $event
    });
    console.log($event);
  }

  editUser($event: User) {
    this.action.emit({
      action: 'edit',
      userObject: $event
    });
  }
}
