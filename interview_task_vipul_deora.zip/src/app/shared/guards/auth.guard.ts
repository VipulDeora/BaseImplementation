import { Injectable } from '@angular/core';
import { Router, CanLoad, Route, UrlSegment } from '@angular/router';
import { Observable } from 'rxjs';

import * as APP_CONST from '../constants/application-constants';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanLoad {
  constructor(private router: Router) {}

  canLoad(route: Route, segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    if (this.checkLogin()) {
      return true;
    } else {
      this.router.navigateByUrl('login').then(() => {});
      return false;
    }
  }

  /**
   * Method that returns if the user is logged in
   * */
  checkLogin() {
    // TODO : Need to look up below code once login is integrated with API.
    return !!(localStorage.getItem('loggedUser') && localStorage.getItem(APP_CONST.AUTHORIZATION));
  }
}
