import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoginService} from './services/login.service';
import {Router} from '@angular/router';

import * as APP_CONST from '../../../shared/constants/application-constants';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  isValidCredentials = true;
  isLoading = false;
  isSignUp = false;

  constructor(private formBuilder: FormBuilder,
              private router: Router,
              private loginService: LoginService) {
  }

  ngOnInit() {
    this.initializeLoginForm();
  }

  private initializeLoginForm() {
    this.loginForm = this.formBuilder.group({
      email: ['eve.holt@reqres.in', [
        Validators.required,
        Validators.email,
        Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')
      ]],
      password: ['cityslicka', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(15)
      ]],
    });
  }

  submit() {
    this.submitted = true;
    this.isLoading = true;
    if (!this.isSignUp) {
      if (this.loginForm.valid) {
        this.isValidCredentials = true;
        this.loginCurrentUser();
      }
    } else {
      this.registerUser();
    }
  }

  onSuccessfulLogin(response: { token: string }) {
    localStorage.clear();
    localStorage.setItem('loggedUser', this.loginForm.controls.email.value);
    localStorage.setItem(APP_CONST.AUTHORIZATION, response.token);
    this.router.navigateByUrl('/').then(() => {
    });
  }

  onSuccessfulRegister(response: {id: number, token: string}) {
    alert('User registered successfully, please login');
    this.toggleSignUp();
  }

  get f() {
    return this.loginForm.controls;
  }

  toggleSignUp() {
    this.isSignUp = !this.isSignUp;
    this.initializeLoginForm();
  }

  private registerUser() {
    this.submitted = false;
    this.loginService.register(this.loginForm.value,
      (response) => {
        this.isLoading = false;
        this.onSuccessfulRegister(response);
      },
      (error) => {
        this.isLoading = false;
        alert(error);
      }
    );
  }

  private loginCurrentUser() {
    this.submitted = false;
    this.loginService.login(this.loginForm.value,
      (response) => {
        this.isLoading = false;
        this.onSuccessfulLogin(response);
      },
      (error) => {
        this.isLoading = false;
        alert(error);
      }
    );
  }
}
