import { Injectable } from '@angular/core';
import {HttpService} from '../../../../shared/services/http.service';
import {environment} from '../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpService: HttpService) { }

  login(body: any, successCallBack, failureCallBack) {
    const URL = environment.BASE_URL + '/api/login';
    this.httpService.executePostRequest(URL, body, successCallBack, failureCallBack);
  }

  register(body: any, successCallBack, failureCallBack) {
    const URL = environment.BASE_URL + '/api/register';
    this.httpService.executePostRequest(URL, body, successCallBack, failureCallBack);
  }
}
