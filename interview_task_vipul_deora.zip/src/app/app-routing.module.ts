import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UserModule} from './user/user.module';
import {UserLoginModule} from './user-login/user-login.module';
import {AuthGuard} from './shared/guards/auth.guard';

const routes: Routes = [
  {
    path: 'login', loadChildren: () => UserLoginModule
  },
  {
    path: '',
    loadChildren: () => UserModule,
    canLoad: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
